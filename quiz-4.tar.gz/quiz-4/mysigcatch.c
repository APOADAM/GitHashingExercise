#include <stdio.h>
#include <signal.h>

void signal_handler(int signum) {
    printf("SIGINT signal caught!\n");
    exit(0);
}

int main() {
    signal(SIGINT, signal_handler);
    while (1) {
        // Infinite loop to keep the program running
    }
    return 0;
}
