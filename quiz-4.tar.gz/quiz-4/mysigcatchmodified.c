#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

// Counter for the number of times SIGINT is caught
int sigint_count = 0;

// Custom signal handler
void custom_signal_handler(int signum) {
    sigint_count++;
    printf("Signal %d caught! (SIGINT caught %d time(s))\n", signum, sigint_count);

    if (sigint_count >= 2) {
        printf("Restoring default SIGINT behavior.\n");
        // Restore the default signal handler
        signal(SIGINT, SIG_DFL);
    }
}

int main() {
    // Set the custom signal handler for SIGINT
    signal(SIGINT, custom_signal_handler);

    printf("Program running. Press Ctrl+C to send SIGINT.\n");

    // Infinite loop to keep the program running
    while (1) {
        // Just a placeholder to simulate a running program
    }

    return 0;
}
